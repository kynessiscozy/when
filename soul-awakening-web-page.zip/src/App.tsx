import React from 'react';
import './index.css';

export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', margin: 0, padding: 0, overflow: 'hidden', backgroundColor: '#050810' }}>
      <iframe src="/game.html" style={{ width: '100%', height: '100%', border: 'none' }} title="Game" />
    </div>
  );
}